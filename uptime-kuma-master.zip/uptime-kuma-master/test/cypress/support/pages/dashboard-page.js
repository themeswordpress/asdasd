exports.DashboardPage = {
    url: Cypress.env("baseUrl") + "/dashboard",
};
