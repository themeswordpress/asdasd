﻿namespace UptimeKuma {
    public class Version {
        public string latest { get; set; }
        public string slow { get; set; }
        public string beta { get; set; }
        public string nodejs { get; set; }
        public string exe { get; set; }
    }
}
